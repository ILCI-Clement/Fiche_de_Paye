import calendar
from datetime import date, datetime, time, timedelta
import holidays
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Alignment, Font
import io
from contract_periods import monthly_exceptions

def heures_vers_texte(nb_heures):
    heures = int(nb_heures)
    minutes = int(round((nb_heures - heures) * 60))
    return f"{heures:02d}:{minutes:02d}"

def calculer_heures(ws, ligne_debut, ligne_fin, col_heure_debut, col_heure_fin, col_resultat):
    fmt = "%H:%M"
    for row in range(ligne_debut, ligne_fin + 1):
        debut = ws.cell(row=row, column=col_heure_debut).value
        fin = ws.cell(row=row, column=col_heure_fin).value

        if isinstance(debut, str) and isinstance(fin, str):
            try:
                h_debut = datetime.strptime(debut, fmt)
                h_fin = datetime.strptime(fin, fmt)
                diff = (h_fin - h_debut).seconds / 3600
                ws.cell(row=row, column=col_resultat, value=heures_vers_texte(diff))
            except ValueError:
                ws.cell(row=row, column=col_resultat, value="")
        else:
            ws.cell(row=row, column=col_resultat, value="")

# Pour regrouper plusieurs jours de congés, d'absences ou d'arret maladies qui se suivent
def regrouper_plages(jours):
    if not jours:
        return []

    # Les anciennes fiches peuvent contenir une ligne de saisie vide. Elle ne
    # correspond à aucune absence et ne doit pas empêcher la génération.
    dates = []
    for valeur in jours:
        if not isinstance(valeur, str):
            continue
        try:
            dates.append(datetime.strptime(valeur, "%Y-%m-%d").date())
        except ValueError:
            continue

    if not dates:
        return []

    dates.sort()
    plages = []

    debut = dates[0]
    fin = dates[0]

    for d in dates[1:]:
        if d == fin + timedelta(days=1):
            fin = d
        else:
            plages.append((debut, fin))
            debut = d
            fin = d

    plages.append((debut, fin))
    return plages

# Fais la somme des heures travaillées (donc 3e colonne) pour chaque semaine ou pour le mois entier
def somme(ws, lignes, col_source, col_resultat, ligne_total, somme):
    total_minutes = 0

    if somme == "semaine":
        for row in lignes:
            val = ws.cell(row=row, column=col_source).value
            if isinstance(val, str):
                try:
                    heures, minutes = map(int, val.split(":"))
                    total_minutes += heures * 60 + minutes
                except:
                    pass

    elif somme == "total":
        for col in col_source:
            val = ws.cell(row=lignes, column=col).value
            if isinstance(val, str):
                try:
                    heures, minutes = map(int, val.split(":"))
                    total_minutes += heures * 60 + minutes
                except:
                    pass

    total_heures = total_minutes // 60
    reste_minutes = total_minutes % 60
    ws.cell(row=ligne_total, column=col_resultat, value=f"{total_heures:02d}:{reste_minutes:02d}")

def remplir_calendrier(ws, mois, annee, vacances, absences, arret, nom, responsable, ddc, fdc, vacances_total, absences_total, arret_total, planning, period_start=None, period_end=None):
    mois_string = ["JANVIER", "FEVRIER", "MARS", "AVRIL", "MAI", "JUIN", "JUILLET", "AOUT", "SEPTEMBRE", "OCTOBRE", "NOVEMBRE", "DECEMBRE"]
    jours_trad = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]

    # Remplissage des infos de base

    ws.cell(row=2, column=27, value=nom)
    ws.cell(row=6, column=27, value=responsable)
    ws.cell(row=2, column=13, value=mois_string[mois-1])
    ws.cell(row=5, column=13, value=annee)
    ws.cell(row=30, column=9, value=vacances_total)
    ws.cell(row=27, column=9, value=absences_total)
    ws.cell(row=27, column=19, value=arret_total)
    ws.cell(row=30, column=29, value=ddc.strftime("%d/%m/%Y"))
    if (isinstance(fdc, date)):
        ws.cell(row=35, column=29, value=fdc.strftime("%d/%m/%Y"))
    else:
        ws.cell(row=35, column=29, value=fdc)

    # Remplissage des groupes de CP, ABS et AM dans la cartouche du bas

    plages_vacances = regrouper_plages(vacances)
    nb_plages_vac = 0

    for d1, d2 in plages_vacances:
        ws.cell(row=30+nb_plages_vac, column=2, value="du")
        ws.cell(row=30+nb_plages_vac, column=3, value=f"{d1.strftime('%d/%m')}")
        ws.cell(row=30+nb_plages_vac, column=4, value="au")
        ws.cell(row=30+nb_plages_vac, column=5, value=f"{d2.strftime('%d/%m')}")
        nb_plages_vac += 1

    plages_absences = regrouper_plages(absences)
    nb_plages_abs = 0

    for d1, d2 in plages_absences:
        ws.cell(row=27+nb_plages_abs, column=2, value="du")
        ws.cell(row=27+nb_plages_abs, column=3, value=f"{d1.strftime('%d/%m')}")
        ws.cell(row=27+nb_plages_abs, column=4, value="au")
        ws.cell(row=27+nb_plages_abs, column=5, value=f"{d2.strftime('%d/%m')}")
        nb_plages_abs += 1
    
    plages_arret = regrouper_plages(arret)
    nb_plages_arret = 0

    for d1, d2 in plages_arret:
        ws.cell(row=27+nb_plages_arret, column=12, value="du")
        ws.cell(row=27+nb_plages_arret, column=13, value=f"{d1.strftime('%d/%m')}")
        ws.cell(row=27+nb_plages_arret, column=14, value="au")
        ws.cell(row=27+nb_plages_arret, column=15, value=f"{d2.strftime('%d/%m')}")
        nb_plages_arret += 1

    # Calcul des jours fériés et du premier jour de la semaine selon le mois et l'année

    jours_feries = holidays.France(years=annee)
    nb_jours = calendar.monthrange(annee, mois)[1]
    premier_jour = date(annee, mois, 1)
    decalage = premier_jour.weekday()

    ligne = 2
    jour = 1
    colonnes = [11, 13, 15, 17, 19, 21, 23]

    # Remplissage des jours dans la cartouche du milieu 
    while jour <= nb_jours:
        for i, col in enumerate(colonnes):
            if i < decalage and jour == 1:
                continue
            if jour > nb_jours:
                break

            cell = ws.cell(row=col, column=ligne, value=jour)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.font = Font(bold=True)

            d = date(annee, mois, jour)
            d_str = d.strftime("%Y-%m-%d")
            nom_jour_fr = jours_trad[d.weekday()]

            if period_start and (d < date.fromisoformat(str(period_start)) or d > date.fromisoformat(str(period_end))):
                ws.merge_cells(start_row=col, start_column=ligne+1, end_row=col+1, end_column=ligne+3)
                ws.cell(row=col, column=ligne+1, value="HORS CONTRAT")
            elif d in jours_feries:
                ws.merge_cells(start_row=col, start_column=ligne+1, end_row=col+1, end_column=ligne+3)
                cell = ws.cell(row=col, column=ligne+1, value="FERIE")
                cell.alignment = Alignment(horizontal="center", vertical="center")

            elif d_str in vacances:
                ws.merge_cells(start_row=col, start_column=ligne+1, end_row=col+1, end_column=ligne+3)
                target_cell = ws.cell(row=col, column=ligne+1)
                target_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

                infos_cp = vacances[d_str]

                if infos_cp["matin"] and infos_cp["aprem"]:   
                    target_cell.value = "CP EXAMEN\nALTERNANCE" if infos_cp.get("examen_alt") else "CP\n09:00 à 17:00"
                elif infos_cp["matin"] and not infos_cp["aprem"]:
                    ws.cell(row=col+1, column=ligne+4, value="04:00")
                    target_cell.value = "CP\n09:00 à 12:00"
                elif not infos_cp["matin"] and infos_cp["aprem"]:
                    ws.cell(row=col, column=ligne+4, value="03:00")
                    target_cell.value = "CP\n13:00 à 17:00"
            elif d_str in absences:
                ws.merge_cells(start_row=col, start_column=ligne+1, end_row=col+1, end_column=ligne+3)
                target_cell = ws.cell(row=col, column=ligne+1)
                target_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

                infos_abs = absences[d_str]

                if infos_abs["matin"] and infos_abs["aprem"]:
                    target_cell.value = "ABS\n09:00 à 17:00"
                elif infos_abs["matin"] and not infos_abs["aprem"]:
                    ws.cell(row=col+1, column=ligne+4, value="04:00")
                    target_cell.value = "ABS\n09:00 à 12:00"
                elif not infos_abs["matin"] and infos_abs["aprem"]:
                    ws.cell(row=col+1, column=ligne+4, value="03:00")
                    target_cell.value = "ABS\n09:00 à 12:00"
            elif d_str in arret:
                ws.merge_cells(start_row=col, start_column=ligne+1, end_row=col+1, end_column=ligne+3)
                target_cell = ws.cell(row=col, column=ligne+1)
                target_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

                infos_am = arret[d_str]

                if infos_am["matin"] and infos_am["aprem"]:
                    target_cell.value = "AM\n09:00 à 17:00"
                elif infos_am["matin"] and not infos_am["aprem"]:
                    ws.cell(row=col+1, column=ligne+4, value="04:00")
                    target_cell.value = "AM\n09:00 à 12:00"
                elif not infos_am["matin"] and infos_am["aprem"]:
                    ws.cell(row=col+1, column=ligne+4, value="03:00")
                    target_cell.value = "AM\n09:00 à 12:00"
            else:
                # Si le jour n'est pas trouvé, on met 'actif': False par sécurité
                config_jour = planning.get(nom_jour_fr, {"actif": False})

                if d.weekday() in [5, 6] or not config_jour.get("actif", True):
                    ws.merge_cells(start_row=col, start_column=ligne+1, end_row=col+1, end_column=ligne+3)
                    val_label = "WEEK-END" if d.weekday() in [5, 6] else "REPOS"
                    cell = ws.cell(row=col, column=ligne+1, value=val_label)
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                else:
                    # On remplit le Matin
                    ws.cell(row=col, column=ligne+1, value=config_jour["m1"])
                    ws.cell(row=col, column=ligne+2, value="à")
                    ws.cell(row=col, column=ligne+3, value=config_jour["m2"])
                        
                    # On remplit l'Après-midi
                    ws.cell(row=col+1, column=ligne+1, value=config_jour["a1"])
                    ws.cell(row=col+1, column=ligne+2, value="à")
                    ws.cell(row=col+1, column=ligne+3, value=config_jour["a2"])

                    calculer_heures(ws, col, col, ligne+1, ligne+3, ligne+4)
                    calculer_heures(ws, col+1, col+1, ligne+1, ligne+3, ligne+4)

            jour += 1

        decalage = 0
        ligne += 5

    # Somme des heures travaillées en semaine

    somme(ws, lignes=[11,12,13,14,15,16,17,18,19,20], col_source=6, col_resultat=2, ligne_total=25, somme="semaine")
    somme(ws, lignes=[11,12,13,14,15,16,17,18,19,20], col_source=11, col_resultat=7, ligne_total=25, somme="semaine")
    somme(ws, lignes=[11,12,13,14,15,16,17,18,19,20], col_source=16, col_resultat=12, ligne_total=25, somme="semaine")
    somme(ws, lignes=[11,12,13,14,15,16,17,18,19,20], col_source=21, col_resultat=17, ligne_total=25, somme="semaine")
    somme(ws, lignes=[11,12,13,14,15,16,17,18,19,20], col_source=26, col_resultat=22, ligne_total=25, somme="semaine")
    somme(ws, lignes=[11,12,13,14,15,16,17,18,19,20], col_source=31, col_resultat=27, ligne_total=25, somme="semaine")

    # Somme des heures travaillées dans le mois

    somme(ws, lignes=25, col_source=[2,7,12,17,22,27], col_resultat=32, ligne_total=25, somme="total")


def convertir_jours(liste):
    dictionnaire_jours = {}
    for j in liste or []:
        if not isinstance(j, dict):
            continue

        valeur_date = j.get("date")
        if valeur_date is None or valeur_date == "":
            continue

        # Formatage de la date en string YYYY-MM-DD pour correspondre à ton calendrier
        date_str = valeur_date.strftime("%Y-%m-%d") if hasattr(valeur_date, "strftime") else str(valeur_date)
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            continue
        
        dictionnaire_jours[date_str] = {
            "matin": j.get("matin", False),
            "aprem": j.get("aprem", False),
            "examen_alt": j.get("examen_alt", False) # <-- On passe l'information ici
        }
    return dictionnaire_jours

# Remplis un calendrier en fonction du nombre d'employés en entrée
def remplir_fiche_paie(mois, annee, employes_data):
    fichier_entree = "Fiche_Exemple.xlsx"
    wb = load_workbook(fichier_entree)
    modele = wb.active

    if employes_data.get("nom"):
        modele.title = employes_data["nom"]
    else:
        modele.title = "Sans nom"
    
    employes_data = monthly_exceptions(employes_data, mois, annee)
    vacances = convertir_jours(employes_data["vacances"])
    vacances_total = 0
    for jour, infos in vacances.items():
        mat = infos["matin"]
        aprem = infos["aprem"]
        
        if (mat and not aprem) or (not mat and aprem):
            vacances_total = vacances_total + 0.5
        elif mat and aprem:
            vacances_total = vacances_total + 1

    absences = convertir_jours(employes_data["absences"])
    absences_total = 0
    for jour, infos in absences.items():
        mat = infos["matin"]
        aprem = infos["aprem"]

        if (mat and not aprem) or (not mat and aprem):
            absences_total = absences_total + 0.5
        elif mat and aprem:
            absences_total = absences_total + 1

    arret = convertir_jours(employes_data["arret"])
    arret_total = 0
    for jour, infos in arret.items():
        mat = infos["matin"]
        aprem = infos["aprem"]

        if (mat and not aprem) or (not mat and aprem):
            arret_total = arret_total + 0.5
        elif mat and aprem:
            arret_total = arret_total + 1

    remplir_calendrier(modele, mois, annee, vacances, absences, arret, employes_data["nom"], employes_data["responsable"], employes_data["ddc"], employes_data["fdc"], vacances_total, absences_total, arret_total, employes_data.get("planning_detail", {}), employes_data.get("sheet_period_start"), employes_data.get("sheet_period_end"))

    # Sauvegarde
    
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer
