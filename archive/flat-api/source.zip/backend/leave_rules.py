"""Paid leave input and authorization, independent of HTTP and storage."""
from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
if __package__:
    from .person_names import person_display_name
else:
    from person_names import person_display_name

Status = Literal['pending', 'approved', 'rejected', 'withdrawn', 'cancelled']
Slot = Literal['full', 'morning', 'afternoon']


class LeaveInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    start_date: date
    end_date: date
    start_slot: Slot = 'full'
    end_slot: Slot = 'full'
    note: str = Field(default='', max_length=2000)

    @model_validator(mode='after')
    def valid_period(self):
        if self.end_date < self.start_date:
            raise ValueError('La fin doit être postérieure ou égale au début.')
        if self.start_date == self.end_date and self.start_slot != self.end_slot:
            raise ValueError('Pour un seul jour, choisissez la même période au début et à la fin.')
        self.note = self.note.strip()
        return self


class LeaveDecision(BaseModel):
    model_config = ConfigDict(extra='forbid')
    decision: Literal['approved', 'rejected']
    comment: str = Field(default='', max_length=2000)
    attendance_confirmation: str | None = Field(default=None, min_length=64, max_length=64)


def roles(actor):
    result = set(actor.get('role_tags') or [actor.get('role')])
    if 'SuperAdmin' in result:
        result.add('Admin')
    return result


def can_review(actor, employee_username, current_manager):
    # Department leadership does not replace the direct-manager relationship.
    return 'Admin' in roles(actor) or (
        'Responsable' in roles(actor)
        and actor['username'] != employee_username
        and actor['username'] == current_manager
    )


def display_name(user):
    return person_display_name(user)
